module <%= session_plural_class_name %>Helper
end
