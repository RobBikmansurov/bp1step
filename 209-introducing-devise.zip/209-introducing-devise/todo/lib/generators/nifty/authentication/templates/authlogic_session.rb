class <%= session_class_name %> < Authlogic::Session::Base
end
