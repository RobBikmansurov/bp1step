module <%= user_plural_class_name %>Helper
end
