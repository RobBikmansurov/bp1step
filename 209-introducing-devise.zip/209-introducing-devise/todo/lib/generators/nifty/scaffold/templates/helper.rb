module <%= plural_class_name %>Helper
end
