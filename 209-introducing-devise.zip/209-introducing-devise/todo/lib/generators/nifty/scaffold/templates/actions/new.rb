  def new
    @<%= instance_name %> = <%= class_name %>.new
  end
