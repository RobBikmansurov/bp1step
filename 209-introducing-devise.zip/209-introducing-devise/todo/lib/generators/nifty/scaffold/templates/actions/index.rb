  def index
    @<%= instances_name %> = <%= class_name %>.all
  end
