class <%= plural_class_name %>Controller < ApplicationController
  <%= controller_methods :actions %>
end
